For training and testing, your directory structure should look like this
  

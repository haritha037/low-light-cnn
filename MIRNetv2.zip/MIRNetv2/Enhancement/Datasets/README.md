For training and testing, your directory structure should look like this
    
 `Datasets` <br/>
 `├──train`  <br/>
     `└──GoPro`   <br/>
          `├──input_crops`   <br/>
          `└──target_crops`   <br/>
 `├──val`  <br/>
     `└──GoPro`   <br/>
          `├──input_crops`   <br/>
          `└──target_crops`   <br/>
 `└──test`  <br/>
     `├──GoPro`   <br/>
          `├──input`   <br/>
          `└──target`   <br/>
     `├──HIDE`  <br/>
          `├──input`   <br/>
          `└──target`   <br/>
     `├──RealBlur_J`  <br/>
          `├──input`   <br/>
          `└──target`   <br/>
     `└──RealBlur_R` <br/>
          `├──input`   <br/>
          `└──target` 
  
